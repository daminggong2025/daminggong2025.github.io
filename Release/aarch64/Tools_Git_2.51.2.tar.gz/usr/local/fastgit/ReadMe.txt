export GITHUB_ACCELERATE=ghfast.top

用法一:
/usr/local/fastgit/bin/git clone https://github.com/xxx/xxx.git --recursive

用法二:
ln -s /usr/local/fastgit/bin/git /usr/bin/git 或 ln -s /usr/local/fastgit/bin/git /usr/local/bin/git
git clone https://github.com/xxx/xxx.git --recursive

用法三:
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/local/fastgit/bin
git clone https://github.com/xxx/xxx.git --recursive
