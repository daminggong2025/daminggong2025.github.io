######################################################################
worker_processes  1;

user nginx;

events {
    worker_connections  1024;
}

http {
    gzip  				on;
    include       		mime.types;
    sendfile        	on;
    default_type  		application/octet-stream;      
    keepalive_timeout	65;

    server {
        listen       80;
        charset		 utf-8;
        server_name  localhost;

        location / {
            root   /WebRoot/Local;
            index  index.html index.htm index.php;
        }

        location ~ \.php$ {
            root           /WebRoot/Local;
            fastcgi_pass   127.0.0.1:9000;
            fastcgi_index  index.php;
            fastcgi_param  SCRIPT_FILENAME $document_root$fastcgi_script_name;
            include        fastcgi_params;
        }
    }
}
######################################################################

######################################################################
worker_processes  1;

user nginx;

events {
    worker_connections  1024;
}

http {
    gzip  				on;
    sendfile        	on;
    default_type  		application/octet-stream;

    server {
        listen       80;
        charset		 utf-8;

        location / {
            root   /WebRoot/Local;
            autoindex on;
            autoindex_localtime on;
            autoindex_exact_size off;
        }
    }

    server {
        listen  443 ssl;
        charset	utf-8;
  
        ssl_ciphers 				ECDHE-RSA-AES128-GCM-SHA256:ECDHE:ECDH:AES:HIGH:!NULL:!aNULL:!MD5:!ADH:!RC4;
        ssl_protocols 				TLSv1 TLSv1.1 TLSv1.2;
        ssl_certificate 		 	/WebCert/Service.pem;
        ssl_certificate_key 		/WebCert/Service.key;
        ssl_session_timeout 	  	5m;
        ssl_prefer_server_ciphers 	on;

        location / {
            root   /WebRoot/Local;
            autoindex on;
            autoindex_localtime on;
            autoindex_exact_size off;
       } 
    }
}
######################################################################
